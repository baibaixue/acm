# -*- coding: utf-8 -*-
"""
Created on Wed Jul  3 21:16:20 2019

@author: Administrator
"""


#%%  1.散点图
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

dataset = pd.read_csv('diamonds.csv')
plt.figure()
plt.title('carat vs price')
plt.xlabel('carat')
plt.ylabel('price')
plt.scatter(dataset['carat'],dataset['price'])
plt.show()


#%%  2.柱状图
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
dataset = pd.read_csv('globalterrorismdb_2017.csv')
top10 = dataset.iloc[0:10, :]
plt.figure()
plt.title('# of Terrorism Ranking')
plt.bar(top10['Country'],top10['Count'])
plt.show()


#%% 3.气泡图
import numpy as np
import pandas as pd
from matplotlib import cm
import matplotlib.pyplot as plt
dataset = pd.read_csv('gpd_lifeexpectancy_population_2015.csv')
population_array = dataset['Population'].values
population_max = population_array.max()
size_list = 1000 * population_array/population_max
color_list = population_array/population_max
plt.figure()
plt.title('GDP vs Life Expectancy')
plt.scatter(dataset['GDP'], dataset['Life Expectancy'], s = size_list, alpha = 0.6, c = size_list, cmap = cm.jet)
plt.show()


#%%  4.折线图
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
dataset = pd.read_csv('life-expectancy.csv')
usa_dataset = dataset[dataset['Code'] == 'USA']
jpn_dataset = dataset[dataset['Code'] == 'JPN']
plt.figure()
plt.title('USA/Japan Life Expectancy Trend')
plt.plot(usa_dataset['Year'], usa_dataset['Life_expectancy'], color = 'red', lw=4, label = 'USA')
plt.plot(jpn_dataset['Year'], jpn_dataset['Life_expectancy'], color = 'blue', lw=4, label = 'Japan')
plt.legend()
plt.show()


#%%  5.饼图
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
dataset = pd.read_csv('titanic.csv')
dataset_upper = dataset[dataset['Pclass'] == 1]
dataset_middle = dataset[dataset['Pclass'] == 2]
dataset_lower = dataset[dataset['Pclass'] == 3]
dataset_labels = ['Upper', 'Middle', 'Lower']
dataset_sizes = [dataset_upper.shape[0], dataset_middle.shape[0], dataset_lower.shape[0]]
dataset_explodes = (0,0,0.1)
plt.figure()
plt.title('Pclass distribution')
plt.pie(dataset_sizes,explode=dataset_explodes, labels=dataset_labels,autopct='%1.1f%%',shadow=False,startangle=150)
plt.show()

#%%  6.雷达图
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style("darkgrid",{"font.sans-serif":['simhei', 'Arial']})

labels = np.array(['知识技能', '执行力', '责任心', '服从力', '抗压能力', '团队协作力'])
stats =  np.array([9.0,        5.5,     9.5,       10,       9.0,        5.2])

angles=np.linspace(0, 2*np.pi, len(labels), endpoint=False) # Set the angle
stats=np.concatenate((stats,[stats[0]]))
angles=np.concatenate((angles,[angles[0]]))
fig = plt.figure()
ax = fig.add_subplot(111, polar = True)   # Set polar axis
ax.plot(angles, stats, 'o-', linewidth=2)  # Draw the plot (or the frame on the radar chart)
ax.fill(angles, stats, alpha=0.25)  #Fulfill the area
ax.set_thetagrids(angles * 180/np.pi, labels)  # Set the label for each axis
ax.set_title('个人评价')
